"""Piezas de la fase 3 ('lienzo vivo'): memoria en flujo, composición lejana, referencias."""
from __future__ import annotations

import copy

import torch
import torch.nn as nn
import torch.nn.functional as F

from .model import NeuroPixel, TinyTransformer
from .task import ROLES, RoleTask


# ------------------------------------------------------------------ memoria en flujo
def np_stream(model: NeuroPixel, frames, steps, out_pos=None):
    """Ejecuta el lienzo sobre una secuencia de fotogramas. Cada fotograma solo es visible
    mientras dura: lo anterior tiene que sobrevivir en el ESTADO (memoria sin contexto)."""
    s = None
    for canvas, st in zip(frames, steps):
        ids = F.embedding(canvas, model.dictionary()).permute(0, 3, 1, 2)
        new = model.seed(ids) * (canvas != 0).unsqueeze(1)
        s = new if s is None else s + new
        for _ in range(st):
            h = torch.cat([s, model.perceive(s), ids], 1)
            ds = model.f2(F.relu(model.f1(h)))
            if model.training and model.fire_rate < 1:
                ds = ds * (torch.rand_like(ds[:, :1]) < model.fire_rate)
            s = s + ds
    r, c = out_pos or model.out_pos
    logits = model.read(s[:, :, r, c]) @ model.dictionary().T
    logits[:, 0] = -1e4
    return {"logits": logits, "state": s}


class FrameGRU(nn.Module):
    """Referencia recurrente clásica para memoria: resume cada fotograma y lo pasa a una GRU."""

    def __init__(self, vocab: int, h: int, w: int, e: int = 8, d: int = 48, hid: int = 64):
        super().__init__()
        self.emb = nn.Embedding(vocab, e)
        self.proj = nn.Linear(h * w * e, d)
        self.gru = nn.GRU(d, hid, batch_first=True)
        self.head = nn.Linear(hid, vocab)

    def forward_frames(self, frames):
        x = torch.stack([F.relu(self.proj(self.emb(f).flatten(1))) for f in frames], 1)
        _, hN = self.gru(x)
        logits = self.head(hN[-1])
        logits[:, 0] = -1e4
        return {"logits": logits}


class MemoryTask:
    """Los 4 hechos [PAPEL][RELLENO] llegan de uno en uno; luego 'delay' fotogramas vacíos;
    al final, solo la pregunta. Hay que recordar sin ver."""

    def __init__(self, task: RoleTask):
        self.t = task

    def sample(self, batch, split, g, device, delay):
        c, y, m = self.t.sample(batch, split, g, device, meta=True)
        B = c.shape[0]
        bi = torch.arange(B, device=c.device)
        frames = []
        for k in range(len(ROLES)):
            f = torch.zeros_like(c)
            r, col = m["rows"][:, k], m["cols"][:, k]
            f[bi, r, col] = c[bi, r, col]
            f[bi, r, col + 1] = c[bi, r, col + 1]
            frames.append(f)
        frames += [torch.zeros_like(c) for _ in range(delay)]
        q = torch.zeros_like(c)
        qr, qc = self.t.query_pos
        q[:, qr, qc] = c[:, qr, qc]
        frames.append(q)
        return frames, y


def memory_steps(delay, fact=3, gap=3, query=10):
    return [fact] * len(ROLES) + [gap] * delay + [query]


# ------------------------------------------------------------------ composición lejana
class RoleTaskFar(RoleTask):
    """Como RoleTask, pero el relleno NO está junto a su papel: misma fila, a 2 o más
    columnas de distancia. La ligadura ya no es 'mi vecino', es 'mi fila'."""

    def sample(self, batch, split="train", generator=None, device="cpu", query_role=None,
               place_pool=None, meta=False):
        c, y, m = super().sample(batch, split, generator, device, query_role, place_pool, meta=True)
        dev = c.device
        g = generator if generator is not None and generator.device == dev else None
        B, R = m["rows"].shape
        bi = torch.arange(B, device=dev).unsqueeze(1).expand(-1, R)
        rows, cols = m["rows"], m["cols"]
        fill_vals = c[bi, rows, cols + 1]
        role_vals = c[bi, rows, cols]
        c[bi, rows, cols] = 0
        c[bi, rows, cols + 1] = 0
        c0 = torch.randint(0, 3, (B, R), generator=g, device=dev)                  # papel a la izquierda
        span = (self.w - 1) - (c0 + 2)                                                 # huecos posibles
        gap = 2 + (torch.rand(B, R, generator=g, device=dev) * (span + 1)).long().clamp(max=span)
        c[bi, rows, c0] = role_vals
        c[bi, rows, c0 + gap] = fill_vals
        qr, qc = self.query_pos
        if meta:
            return c, y, {"rows": rows, "cols": c0, "fill_cols": c0 + gap, "fillers": m["fillers"]}
        return c, y


# ------------------------------------------------------------------ ampliar diccionario (palabra nueva)
def expand_vocab(model, new: int = 1):
    """Return a copied native model, trainable tensors, and first appended ID.

    Existing dictionary/grounding rows and non-vocabulary tensors are preserved.
    Only appended rows receive gradients through the returned tensors. This is
    not an optimizer-level freeze: use a fresh optimizer with no weight decay
    or inherited momentum, as the historical callers do. Existing optimizers
    still reference the original model and are not migrated.

    This operation supports the native NeuroPixel and TinyTransformer classes;
    subclasses with extra vocabulary-dependent tables require their own policy.
    Grounding buffers remain nonpersistent, so state_dict alone still cannot
    reconstruct a grounded model. Gradient hooks likewise require reapplying
    this expansion policy when reconstructing a model for further adaptation.
    """
    if type(new) is not int or new <= 0:
        raise ValueError("new must be a positive integer")
    if type(model) not in (NeuroPixel, TinyTransformer):
        raise TypeError("expand_vocab supports native NeuroPixel or TinyTransformer")
    m = copy.deepcopy(model)
    if isinstance(m, NeuroPixel):
        old = m.embed.weight.detach()
        first = old.shape[0]
        V = first + new
        emb = nn.Embedding(V, old.shape[1], padding_idx=0).to(device=old.device, dtype=old.dtype)
        with torch.no_grad():
            emb.weight[:first] = old
            # Preserve the historical initialization for ordinary float32 models.
            emb.weight[first:] = old[1:].std() * torch.randn(
                new, old.shape[1], device=old.device, dtype=old.dtype)
        m.embed = emb
        m.register_buffer("g_rgb", torch.cat([m.g_rgb, m.g_rgb.new_zeros((new, 3))]), persistent=False)
        m.register_buffer("g_mask", torch.cat([m.g_mask, m.g_mask.new_zeros((new, 1))]), persistent=False)
        train = [m.embed.weight]
    else:
        old_t, old_h, old_b = m.tok.weight.detach(), m.head.weight.detach(), m.head.bias.detach()
        first = old_t.shape[0]
        V = first + new
        d = old_t.shape[1]
        m.tok = nn.Embedding(V, d).to(device=old_t.device, dtype=old_t.dtype)
        m.head = nn.Linear(d, V).to(device=old_h.device, dtype=old_h.dtype)
        with torch.no_grad():
            m.tok.weight[:first] = old_t
            m.tok.weight[first:] = old_t.std() * torch.randn(
                new, d, device=old_t.device, dtype=old_t.dtype)
            m.head.weight[:first] = old_h
            m.head.weight[first:] = old_h.std() * torch.randn(
                new, d, device=old_h.device, dtype=old_h.dtype)
            m.head.bias[:first] = old_b
            m.head.bias[first:] = old_b.mean()
        train = [m.tok.weight, m.head.weight, m.head.bias]
    for p in m.parameters():
        p.requires_grad_(False)
    for p in train:
        p.requires_grad_(True)
        # Boolean row selection follows the actual gradient device after .to().
        rows = torch.arange(V, device=p.device) >= first
        p.register_hook(lambda gr, rows=rows: gr * rows.to(device=gr.device).reshape(
            (-1,) + (1,) * (gr.dim() - 1)))
    return m, train, first
